package com.udacity.stockhawk.ui;

import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IFillFormatter;
import com.github.mikephil.charting.interfaces.dataprovider.LineDataProvider;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.udacity.stockhawk.R;
import com.udacity.stockhawk.data.Contract;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by viji on 27-Feb-17.
 */

public class DetailsFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor>  {

    // Bindviews
    @BindView(R.id.chart)
    LineChart mChart;
    @BindView(R.id.symbol)
    TextView symbol;
    @BindView(R.id.price)
    TextView price;
    @BindView(R.id.change)
    TextView change;

    // Static key value for bundle uri
    static final String DETAIL_URI = "URI";

    private Uri mUri;

    // Loader id
    private static final int DETAIL_LOADER = 7;

    // Text format
    private DecimalFormat dollarFormat;
    private DecimalFormat percentageFormat;

    public DetailsFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_details, container, false);
        ButterKnife.bind(this, view);

        Bundle arguments = getArguments();
        if (arguments != null && arguments.containsKey(DETAIL_URI)) {
            mUri = arguments.getParcelable(DETAIL_URI);
        }

        // initialize Graph View
        initGraphView();

        // Setup Text format percentage / currency
        dollarFormat = (DecimalFormat) NumberFormat.getCurrencyInstance(Locale.US);
        percentageFormat = (DecimalFormat) NumberFormat.getPercentInstance(Locale.getDefault());
        percentageFormat.setMaximumFractionDigits(2);
        percentageFormat.setMinimumFractionDigits(2);
        percentageFormat.setPositivePrefix("+");

        // Output view
        return view;
    }

    private void initGraphView() {

        // no description text
        mChart.getDescription().setEnabled(false);

        // enable touch gestures
        mChart.setTouchEnabled(false);

        // if disabled, scaling can be done on x- and y-axis separately
        mChart.setPinchZoom(false);

        mChart.setDrawGridBackground(false);

        // Disable x-axis
        XAxis x = mChart.getXAxis();
        x.setEnabled(false);

        // Setup y-axis
        YAxis y = mChart.getAxisLeft();
        y.setLabelCount(6, false);
        y.setTextColor(Color.WHITE);
        y.setPosition(YAxis.YAxisLabelPosition.INSIDE_CHART);
        y.setDrawGridLines(false);
        y.setAxisLineColor(Color.WHITE);

        mChart.getAxisRight().setEnabled(false);
        mChart.getLegend().setEnabled(false);

        // Simple animation
        mChart.animateXY(500, 500);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        getLoaderManager().initLoader(DETAIL_LOADER, null, this);
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        if ( null != mUri ) {
            // Now create and return a CursorLoader that will take care of
            // creating a Cursor for the data being displayed.
            return new CursorLoader(
                    getActivity(),
                    mUri,
                    Contract.Quote.QUOTE_COLUMNS.toArray(new String[]{}),
                    null,
                    null,
                    null
            );
        }

        return null;
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

        if (data != null && data.moveToFirst()) {
            // Read low temperature from cursor and update view
            String[] stockHistory = data.getString(Contract.Quote.POSITION_HISTORY).split("\n");

            int totalHistory = stockHistory.length > 10 ? 10 : stockHistory.length-1;
            ArrayList<Entry> yVals = new ArrayList<>();

            for (int i = 0; i < totalHistory; i++) {
                if (stockHistory[i].contains(",")) {
                    float val = Float.parseFloat(stockHistory[i].split(", ")[1]);
                    yVals.add(new Entry(i, val));
                }
            }

            // Set data
            setData(yVals);

            // dont forget to refresh the drawing
            mChart.invalidate();

            // Set details
            symbol.setText(data.getString(Contract.Quote.POSITION_SYMBOL));
            price.setText(dollarFormat.format(data.getFloat(Contract.Quote.POSITION_PRICE)));

            float rawAbsoluteChange = data.getFloat(Contract.Quote.POSITION_ABSOLUTE_CHANGE);
            float percentageChange = data.getFloat(Contract.Quote.POSITION_PERCENTAGE_CHANGE);

            if (rawAbsoluteChange > 0) {
                change.setBackgroundResource(R.drawable.percent_change_pill_green);
            } else {
                change.setBackgroundResource(R.drawable.percent_change_pill_red);
            }

            String percentage = percentageFormat.format(percentageChange / 100);
            change.setText(percentage);
        }

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {}

    private void setData(ArrayList<Entry> yVals) {

        LineDataSet set1;
        if (mChart.getData() != null &&
                mChart.getData().getDataSetCount() > 0) {
            set1 = (LineDataSet)mChart.getData().getDataSetByIndex(0);
            set1.setValues(yVals);
            mChart.getData().notifyDataChanged();
            mChart.notifyDataSetChanged();
        } else {
            // create a dataset and give it a type
            set1 = new LineDataSet(yVals, "DataSet 1");

            set1.setMode(LineDataSet.Mode.CUBIC_BEZIER);
            set1.setCubicIntensity(0.2f);
            set1.setDrawFilled(true);
            set1.setDrawCircles(false);
            set1.setLineWidth(1.8f);
            set1.setCircleRadius(4f);
            set1.setCircleColor(Color.WHITE);
            set1.setHighLightColor(Color.rgb(244, 117, 117));
            set1.setColor(Color.WHITE);
            //set1.setFillColor(Color.WHITE);
            set1.setFillAlpha(100);
            set1.setDrawHorizontalHighlightIndicator(false);
            set1.setFillFormatter(new IFillFormatter() {
                @Override
                public float getFillLinePosition(ILineDataSet dataSet, LineDataProvider dataProvider) {
                    return -10;
                }
            });

            // create a data object with the datasets
            LineData data = new LineData(set1);
            data.setValueTextSize(9f);
            data.setDrawValues(false);

            // set data
            mChart.setData(data);
        }
    }
}
